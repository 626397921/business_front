<template>
  <div>
    <h2 style="color: green;">🎉 登录成功!</h2>
    <div style="border: 1px solid #eee; padding: 20px; max-width: 500px; margin: 20px auto; border-radius: 8px;">
      <p>用户名: CZH</p>
      <p>角色: 超级管理员</p>
      <p style="color: #999;">这是首页占位页，暂无实际功能</p>
      <!-- 移除按钮：跳转逻辑交给侧边栏 -->
    </div>
  </div>
</template>

<script setup>
// 无需额外代码，保留原有逻辑即可
</script>

<style scoped>
/* 保留原有样式（如果有） */
</style>